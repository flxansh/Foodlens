import 'package:flutter_test/flutter_test.dart';
import 'package:foodlens/models/analysis.dart';
import 'package:foodlens/services/ingredient_analyzer.dart';
import 'package:foodlens/services/ingredient_parser.dart';

void main() {
  group('IngredientParser', () {
    test('reads a simple label and stops at the advisory', () {
      final parsed = IngredientParser.parse(
        'INGREDIENTS: Wheat flour, sugar, palm oil (sustainable), salt.\n'
        'May contain traces of nuts.\nStore in a cool place',
      );
      expect(parsed.ingredients, ['Wheat flour', 'Sugar', 'Palm oil (sustainable)', 'Salt']);
      expect(parsed.advisory, 'May contain traces of nuts');
    });

    test('keeps commas inside brackets together', () {
      final parsed = IngredientParser.parse(
        'Ingredients: Chocolate (sugar, cocoa butter, milk powder), salt',
      );
      expect(parsed.ingredients, [
        'Chocolate (sugar, cocoa butter, milk powder)',
        'Salt',
      ]);
    });

    test('handles US "2% or less" wording and ALL CAPS', () {
      final parsed = IngredientParser.parse(
        'INGREDIENTS: ENRICHED FLOUR, SUGAR. CONTAINS 2% OR LESS OF: SALT, SOY LECITHIN.',
      );
      expect(parsed.ingredients, ['Enriched flour', 'Sugar', 'Salt', 'Soy lecithin']);
    });

    test('returns nothing for text without ingredients', () {
      expect(IngredientParser.parse('').ingredients, isEmpty);
    });
  });

  group('IngredientAnalyzer', () {
    test('finds milk in a compound ingredient but not in cocoa butter', () {
      expect(
        IngredientAnalyzer.analyzeIngredient('Chocolate (sugar, cocoa butter, milk powder)').allergens,
        {'milk'},
      );
      expect(IngredientAnalyzer.analyzeIngredient('Cocoa butter').allergens, isEmpty);
    });

    test('plant milks are not dairy but keep their own allergen', () {
      final almond = IngredientAnalyzer.analyzeIngredient('Almond milk');
      expect(almond.allergens, {'tree_nuts'});
      expect(almond.dietFlags.contains('vegan'), isFalse);
    });

    test('flags additives by E-number and by name', () {
      expect(IngredientAnalyzer.analyzeIngredient('Colour (E102)').risk, Risk.caution);
      expect(IngredientAnalyzer.analyzeIngredient('Tartrazine').risk, Risk.caution);
      expect(IngredientAnalyzer.analyzeIngredient('Citric acid').risk, Risk.safe);
    });

    test('partially hydrogenated oil is avoid, and soy is detected', () {
      final info = IngredientAnalyzer.analyzeIngredient('Partially hydrogenated soybean oil');
      expect(info.risk, Risk.avoid);
      expect(info.allergens, {'soy'});
    });

    test('gelatin breaks vegan, vegetarian and halal', () {
      final info = IngredientAnalyzer.analyzeIngredient('Gelatin');
      expect(info.dietFlags, containsAll(['vegan', 'vegetarian', 'halal']));
    });

    test('score drops as concerns add up', () {
      final clean = IngredientAnalyzer.analyze(['Oats', 'Water', 'Salt']);
      final busy = IngredientAnalyzer.analyze(['Tartrazine', 'Aspartame', 'Partially hydrogenated oil']);
      expect(clean.score, 100);
      expect(busy.score, lessThan(clean.score));
    });
  });
}
