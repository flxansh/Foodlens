"""FoodLens API: names a dish and lists its likely ingredients from a photo.

The mobile app never holds the Anthropic API key. It sends the photo here, and
this service calls the model.

Run:  uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import base64
import hmac
import io
import json
import os
import re
from functools import lru_cache
from typing import Any

import anthropic
from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError

MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")
APP_KEY = os.getenv("APP_KEY", "")
MAX_UPLOAD_BYTES = 12 * 1024 * 1024
MAX_SIDE = 1568  # larger images are downscaled; the model gains nothing from more

SYSTEM_PROMPT = """You identify food from photos for an ingredient-checking app.

Reply with one JSON object and nothing else, in exactly this shape:
{"title": "...", "ingredients": ["..."], "confidence": "high|medium|low", "notes": "..."}

Rules:
- title: a short dish or product name, such as "Margherita pizza".
- ingredients: plain, common, lowercase names ("wheat flour", "butter", "egg").
  Include ingredients that are typical of this dish even when they are not
  visible (for example butter in a croissant), and mention that in notes.
- confidence: how sure you are about the dish and its ingredients.
- notes: one short sentence about anything uncertain or impossible to see.
- If the image does not show food, return an empty ingredients list, the title
  "No food found", and a note that says what you see instead.
- Never invent brand names. No markdown, no text outside the JSON."""

app = FastAPI(title="FoodLens API")


@lru_cache(maxsize=1)
def get_client() -> anthropic.Anthropic:
    # Reads ANTHROPIC_API_KEY from the environment.
    return anthropic.Anthropic()


def require_key(x_app_key: str | None = Header(default=None)) -> None:
    """Optional shared-secret check. Skipped when APP_KEY is not set."""
    if APP_KEY and not hmac.compare_digest(x_app_key or "", APP_KEY):
        raise HTTPException(status_code=401, detail="Invalid app key.")


def prepare_image(data: bytes) -> str:
    """Fix rotation, shrink, re-encode as JPEG and return base64."""
    image = Image.open(io.BytesIO(data))
    image = ImageOps.exif_transpose(image).convert("RGB")
    image.thumbnail((MAX_SIDE, MAX_SIDE))
    buffer = io.BytesIO()
    image.save(buffer, "JPEG", quality=85)
    return base64.standard_b64encode(buffer.getvalue()).decode("ascii")


def extract_json(text: str) -> dict[str, Any]:
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end <= start:
        raise ValueError("No JSON object in model reply")
    parsed = json.loads(cleaned[start : end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("Model reply was not a JSON object")
    return parsed


def normalise(raw: dict[str, Any]) -> dict[str, Any]:
    ingredients: list[str] = []
    for item in raw.get("ingredients") or []:
        name = str(item).strip().lower()
        if name and name not in ingredients:
            ingredients.append(name)
    confidence = str(raw.get("confidence", "medium")).lower()
    if confidence not in {"high", "medium", "low"}:
        confidence = "medium"
    return {
        "title": str(raw.get("title") or "Food photo").strip()[:80],
        "ingredients": ingredients[:40],
        "confidence": confidence,
        "notes": str(raw.get("notes") or "").strip()[:240] or None,
    }


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


# A plain `def` (not async) so FastAPI runs this blocking call in a worker thread.
@app.post("/analyze-food", dependencies=[Depends(require_key)])
def analyze_food(image: UploadFile = File(...)) -> dict[str, Any]:
    data = image.file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Image is too large.")

    try:
        encoded = prepare_image(data)
    except (UnidentifiedImageError, OSError) as exc:
        raise HTTPException(status_code=400, detail="Could not read the image.") from exc

    try:
        response = get_client().messages.create(
            model=MODEL,
            max_tokens=1000,
            system=SYSTEM_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/jpeg",
                                "data": encoded,
                            },
                        },
                        {"type": "text", "text": "Identify the food and list its likely ingredients."},
                    ],
                }
            ],
        )
    except anthropic.APIError as exc:
        raise HTTPException(status_code=502, detail="The vision service is unavailable.") from exc

    text = "".join(block.text for block in response.content if getattr(block, "type", "") == "text")
    try:
        return normalise(extract_json(text))
    except ValueError as exc:  # includes json.JSONDecodeError
        raise HTTPException(status_code=502, detail="Could not understand the vision reply.") from exc
