enum ScanSource { label, food }

/// One saved scan. Only the ingredient names are stored; the analysis is
/// recomputed when a scan is opened, so history benefits from database updates.
class ScanEntry {
  const ScanEntry({
    required this.id,
    required this.createdAt,
    required this.source,
    required this.title,
    required this.ingredients,
    this.advisory,
    this.note,
  });

  factory ScanEntry.create({
    required ScanSource source,
    required String title,
    required List<String> ingredients,
    String? advisory,
    String? note,
  }) {
    final now = DateTime.now();
    return ScanEntry(
      id: now.microsecondsSinceEpoch.toString(),
      createdAt: now,
      source: source,
      title: title,
      ingredients: ingredients,
      advisory: advisory,
      note: note,
    );
  }

  factory ScanEntry.fromJson(Map<String, dynamic> json) {
    return ScanEntry(
      id: json['id'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      source: json['source'] == 'food' ? ScanSource.food : ScanSource.label,
      title: json['title'] as String,
      ingredients: (json['ingredients'] as List).map((e) => e.toString()).toList(),
      advisory: json['advisory'] as String?,
      note: json['note'] as String?,
    );
  }

  final String id;
  final DateTime createdAt;
  final ScanSource source;
  final String title;
  final List<String> ingredients;

  /// Allergen statements printed on a label, such as "may contain nuts".
  final String? advisory;

  /// Extra context, such as what a photo analysis could not see.
  final String? note;

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'source': source == ScanSource.food ? 'food' : 'label',
        'title': title,
        'ingredients': ingredients,
        'advisory': advisory,
        'note': note,
      };
}
