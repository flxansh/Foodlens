/// How worried the app is about a single ingredient.
enum Risk { safe, caution, avoid }

class IngredientInfo {
  const IngredientInfo({
    required this.name,
    required this.risk,
    this.notes = const [],
    this.allergens = const {},
    this.dietFlags = const {},
  });

  final String name;
  final Risk risk;

  /// Short explanations, for example why an additive is flagged.
  final List<String> notes;

  /// Allergen ids found in this ingredient (see allergenLabels).
  final Set<String> allergens;

  /// Diet ids this ingredient conflicts with (see dietLabels).
  final Set<String> dietFlags;
}

class Analysis {
  const Analysis({
    required this.items,
    required this.allergens,
    required this.dietConflicts,
    required this.score,
  });

  final List<IngredientInfo> items;

  /// Every allergen id found across all ingredients.
  final Set<String> allergens;

  /// Diet id -> names of the ingredients that break it.
  final Map<String, Set<String>> dietConflicts;

  /// 0 to 100. A rough guide based only on the ingredient list.
  final int score;

  int get cautionCount => items.where((i) => i.risk == Risk.caution).length;
  int get avoidCount => items.where((i) => i.risk == Risk.avoid).length;
  int get safeCount => items.length - cautionCount - avoidCount;
}
