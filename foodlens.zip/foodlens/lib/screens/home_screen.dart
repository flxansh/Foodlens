import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/scan_entry.dart';
import '../services/scan_exception.dart';
import '../services/scan_pipeline.dart';
import '../services/storage.dart';
import 'history_screen.dart';
import 'profile_screen.dart';
import 'results_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final ScanPipeline _pipeline = ScanPipeline();
  final HistoryStore _history = HistoryStore();
  final ImagePicker _picker = ImagePicker();

  CameraController? _camera;
  ScanMode _mode = ScanMode.auto;
  bool _busy = false;
  bool _torchOn = false;
  String _status = '';
  String? _cameraError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startCamera();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _camera?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final camera = _camera;
    if (state == AppLifecycleState.inactive && camera != null) {
      setState(() => _camera = null);
      camera.dispose();
    } else if (state == AppLifecycleState.resumed && _camera == null) {
      _startCamera();
    }
  }

  Future<void> _startCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        if (mounted) setState(() => _cameraError = 'No camera found on this device.');
        return;
      }
      final back = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      final controller = CameraController(back, ResolutionPreset.high, enableAudio: false);
      await controller.initialize();
      await controller.setFlashMode(FlashMode.off);
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() {
        _camera = controller;
        _cameraError = null;
        _torchOn = false;
      });
    } on CameraException catch (e) {
      if (!mounted) return;
      setState(() {
        _cameraError = e.code == 'CameraAccessDenied'
            ? 'Camera access is off. Turn it on in Settings, or pick a photo from your gallery.'
            : 'The camera could not start (${e.description ?? e.code}).';
      });
    }
  }

  Future<void> _toggleTorch() async {
    final camera = _camera;
    if (camera == null || !camera.value.isInitialized) return;
    try {
      await camera.setFlashMode(_torchOn ? FlashMode.off : FlashMode.torch);
      setState(() => _torchOn = !_torchOn);
    } on CameraException {
      _toast("This camera doesn't support the light.");
    }
  }

  Future<void> _capture() async {
    final camera = _camera;
    if (_busy || camera == null || !camera.value.isInitialized || camera.value.isTakingPicture) {
      return;
    }
    try {
      final file = await camera.takePicture();
      await _process(file.path);
    } on CameraException catch (e) {
      _toast("Couldn't take the photo (${e.description ?? e.code}).");
    }
  }

  Future<void> _pickFromGallery() async {
    if (_busy) return;
    try {
      final file = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 2200);
      if (file != null) await _process(file.path);
    } catch (_) {
      _toast("Couldn't open your photos. Check the photo permission in Settings.");
    }
  }

  Future<void> _process(String path) async {
    setState(() {
      _busy = true;
      _status = 'Scanning…';
    });
    ScanEntry? entry;
    try {
      entry = await _pipeline.run(
        path,
        _mode,
        onStatus: (s) {
          if (mounted) setState(() => _status = s);
        },
      );
      await _history.add(entry);
    } on ScanException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Something went wrong while scanning. Please try again.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    if (entry != null && mounted) await _open(ResultsScreen(entry: entry));
  }

  Future<void> _open(Widget screen) async {
    try {
      await _camera?.pausePreview();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => screen));
    try {
      await _camera?.resumePreview();
    } catch (_) {}
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  String get _hint {
    switch (_mode) {
      case ScanMode.auto:
        return 'Point at an ingredient list or a dish';
      case ScanMode.label:
        return 'Fit the ingredient list inside the frame';
      case ScanMode.food:
        return 'Show the whole dish in good light';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: _preview()),
          Positioned.fill(
            child: IgnorePointer(
              child: Center(
                child: FractionallySizedBox(
                  widthFactor: 0.86,
                  heightFactor: 0.42,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white70, width: 2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _topBar(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: _modeSelector(),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Text(
                    _hint,
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                ),
                _controls(),
                const SizedBox(height: 20),
              ],
            ),
          ),
          if (_busy) _busyOverlay(),
        ],
      ),
    );
  }

  Widget _preview() {
    final camera = _camera;
    if (_cameraError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _cameraError!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _startCamera, child: const Text('Try again')),
            ],
          ),
        ),
      );
    }
    if (camera == null || !camera.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    final size = camera.value.previewSize!;
    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          // The preview size is reported in landscape, so swap for portrait.
          width: size.height,
          height: size.width,
          child: CameraPreview(camera),
        ),
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 8, 0),
      child: Row(
        children: [
          const Text(
            'FoodLens',
            style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700),
          ),
          const Spacer(),
          IconButton(
            tooltip: 'History',
            color: Colors.white,
            icon: const Icon(Icons.history),
            onPressed: () => _open(const HistoryScreen()),
          ),
          IconButton(
            tooltip: 'My allergens and diets',
            color: Colors.white,
            icon: const Icon(Icons.tune),
            onPressed: () => _open(const ProfileScreen()),
          ),
        ],
      ),
    );
  }

  Widget _modeSelector() {
    return SegmentedButton<ScanMode>(
      showSelectedIcon: false,
      style: SegmentedButton.styleFrom(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        selectedBackgroundColor: Colors.white,
        selectedForegroundColor: Colors.black,
      ),
      segments: const [
        ButtonSegment(value: ScanMode.auto, label: Text('Auto')),
        ButtonSegment(value: ScanMode.label, label: Text('Label')),
        ButtonSegment(value: ScanMode.food, label: Text('Food')),
      ],
      selected: {_mode},
      onSelectionChanged: (s) => setState(() => _mode = s.first),
    );
  }

  Widget _controls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton.filledTonal(
          tooltip: 'Choose a photo',
          iconSize: 28,
          onPressed: _busy ? null : _pickFromGallery,
          icon: const Icon(Icons.photo_library_outlined),
        ),
        Semantics(
          button: true,
          label: 'Scan',
          child: GestureDetector(
            onTap: _busy ? null : _capture,
            child: Container(
              width: 80,
              height: 80,
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 4),
              ),
              child: const DecoratedBox(
                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
              ),
            ),
          ),
        ),
        IconButton.filledTonal(
          tooltip: _torchOn ? 'Turn light off' : 'Turn light on',
          iconSize: 28,
          onPressed: _busy ? null : _toggleTorch,
          icon: Icon(_torchOn ? Icons.flashlight_on : Icons.flashlight_off),
        ),
      ],
    );
  }

  Widget _busyOverlay() {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black54,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              Text(_status, style: const TextStyle(color: Colors.white, fontSize: 16)),
            ],
          ),
        ),
      ),
    );
  }
}
