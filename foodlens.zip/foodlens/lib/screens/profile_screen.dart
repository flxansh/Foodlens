import 'package:flutter/material.dart';

import '../data/knowledge.dart';
import '../services/storage.dart';

/// Lets the user say what they avoid. Saved on the device as they tap.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ProfileStore _store = ProfileStore();
  Set<String> _allergens = {};
  Set<String> _diets = {};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final profile = await _store.load();
    if (!mounted) return;
    setState(() {
      _allergens = {...profile.allergens};
      _diets = {...profile.diets};
      _loaded = true;
    });
  }

  void _toggle(Set<String> set, String id, bool on) {
    setState(() => on ? set.add(id) : set.remove(id));
    _store.save(UserProfile(allergens: _allergens, diets: _diets));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('My allergens and diets')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Allergens I avoid', style: theme.textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Scans that contain these are flagged in red.',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final e in allergenLabels.entries)
                      FilterChip(
                        label: Text(e.value),
                        selected: _allergens.contains(e.key),
                        onSelected: (on) => _toggle(_allergens, e.key, on),
                      ),
                  ],
                ),
                const SizedBox(height: 28),
                Text('Diets I follow', style: theme.textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Ingredients that break a diet are called out by name.',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final e in dietLabels.entries)
                      FilterChip(
                        label: Text(e.value),
                        selected: _diets.contains(e.key),
                        onSelected: (on) => _toggle(_diets, e.key, on),
                      ),
                  ],
                ),
                const SizedBox(height: 28),
                Text(
                  'Your choices stay on this device.',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
    );
  }
}
