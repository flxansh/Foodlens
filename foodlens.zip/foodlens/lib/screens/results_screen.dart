import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/knowledge.dart';
import '../models/analysis.dart';
import '../models/scan_entry.dart';
import '../services/ingredient_analyzer.dart';
import '../services/storage.dart';
import '../theme.dart';
import 'profile_screen.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key, required this.entry});

  final ScanEntry entry;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  late final Analysis _analysis = IngredientAnalyzer.analyze(widget.entry.ingredients);
  late final Set<String> _advisoryAllergens = widget.entry.advisory == null
      ? <String>{}
      : IngredientAnalyzer.allergensIn(widget.entry.advisory!);
  UserProfile? _profile;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final profile = await ProfileStore().load();
    if (mounted) setState(() => _profile = profile);
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.entry.ingredients.join(', ')));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ingredients copied')),
    );
  }

  Future<void> _editProfile() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
    );
    _loadProfile();
  }

  String _labels(Iterable<String> ids, Map<String, String> names) =>
      ids.map((id) => names[id] ?? id).join(', ');

  @override
  Widget build(BuildContext context) {
    final entry = widget.entry;
    final theme = Theme.of(context);
    final isLabel = entry.source == ScanSource.label;

    return Scaffold(
      appBar: AppBar(
        title: Text(entry.title),
        actions: [
          IconButton(
            tooltip: 'Copy ingredients',
            icon: const Icon(Icons.copy_all_outlined),
            onPressed: _copy,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          if (isLabel) _summary(theme),
          ..._alerts(theme),
          if (_analysis.allergens.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Contains', style: theme.textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final id in _analysis.allergens)
                  Chip(
                    label: Text(allergenLabels[id] ?? id),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
          ],
          const SizedBox(height: 20),
          Text(
            '${entry.ingredients.length} ingredients',
            style: theme.textTheme.titleMedium,
          ),
          const SizedBox(height: 10),
          _ingredientTape(theme),
          const SizedBox(height: 12),
          _legend(theme),
          const SizedBox(height: 20),
          Text(
            isLabel
                ? 'Text is read from a photo and can be misread. Diet and allergen checks are keyword based and cannot see certifications or cross-contamination. If you have a serious allergy, always check the package itself.'
                : 'This is an estimate from a photo. Hidden ingredients such as oils, sauces and allergens cannot be seen, so ask the cook or maker if you have a serious allergy.',
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          if (entry.note != null && entry.note!.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              entry.note!,
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ],
        ],
      ),
    );
  }

  Widget _summary(ThemeData theme) {
    final a = _analysis;
    final String verdict;
    if (a.score >= 80) {
      verdict = 'Looks clean';
    } else if (a.score >= 50) {
      verdict = 'Some to watch';
    } else {
      verdict = 'Several to watch';
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(verdict, style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(
            'Score ${a.score} out of 100, a rough guide from the ingredient list',
            style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              height: 10,
              child: Row(
                children: [
                  if (a.safeCount > 0)
                    Expanded(flex: a.safeCount, child: ColoredBox(color: RiskStyle.color(Risk.safe))),
                  if (a.cautionCount > 0)
                    Expanded(flex: a.cautionCount, child: ColoredBox(color: RiskStyle.color(Risk.caution))),
                  if (a.avoidCount > 0)
                    Expanded(flex: a.avoidCount, child: ColoredBox(color: RiskStyle.color(Risk.avoid))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${a.safeCount} fine, ${a.cautionCount} to watch, ${a.avoidCount} to avoid',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  List<Widget> _alerts(ThemeData theme) {
    final profile = _profile;
    if (profile == null) return const [];

    if (profile.isEmpty) {
      return [
        Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: const Icon(Icons.tune),
            title: const Text('Get alerts that fit you'),
            subtitle: const Text('Choose your allergens and diets.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _editProfile,
          ),
        ),
      ];
    }

    final allergenHits = profile.allergens.intersection(_analysis.allergens);
    final advisoryHits =
        profile.allergens.intersection(_advisoryAllergens).difference(allergenHits);
    final alerts = <Widget>[];

    if (allergenHits.isNotEmpty) {
      alerts.add(_AlertCard(
        icon: Icons.warning_amber_rounded,
        color: RiskStyle.color(Risk.avoid),
        title: 'Contains your allergens',
        body: _labels(allergenHits, allergenLabels),
      ));
    }
    if (advisoryHits.isNotEmpty) {
      alerts.add(_AlertCard(
        icon: Icons.info_outline,
        color: RiskStyle.color(Risk.caution),
        title: 'Label warns of your allergens',
        body: '${_labels(advisoryHits, allergenLabels)}: ${widget.entry.advisory}',
      ));
    }
    for (final diet in profile.diets) {
      final causes = _analysis.dietConflicts[diet];
      if (causes == null || causes.isEmpty) continue;
      alerts.add(_AlertCard(
        icon: Icons.block,
        color: RiskStyle.color(Risk.caution),
        title: dietBreakTitles[diet] ?? 'Conflicts with ${dietLabels[diet]}',
        body: 'Because of ${causes.join(', ').toLowerCase()}',
      ));
    }
    if (alerts.isEmpty) {
      alerts.add(_AlertCard(
        icon: Icons.check_circle_outline,
        color: RiskStyle.color(Risk.safe),
        title: 'No matches with your profile',
        body: 'Based on what was detected.',
      ));
    }
    return alerts;
  }

  /// One long strip: each ingredient carries a colored bar, and the bars
  /// stack into a continuous tape showing where the concerns sit in the list.
  Widget _ingredientTape(ThemeData theme) {
    final items = _analysis.items;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          for (var i = 0; i < items.length; i++)
            _IngredientRow(info: items[i], isLast: i == items.length - 1),
        ],
      ),
    );
  }

  Widget _legend(ThemeData theme) {
    Widget dot(Risk risk) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(color: RiskStyle.color(risk), shape: BoxShape.circle),
            ),
            const SizedBox(width: 6),
            Text(RiskStyle.label(risk), style: theme.textTheme.bodySmall),
          ],
        );
    return Wrap(
      spacing: 16,
      children: [dot(Risk.safe), dot(Risk.caution), dot(Risk.avoid)],
    );
  }
}

class _AlertCard extends StatelessWidget {
  const _AlertCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.body,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withAlpha(31),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withAlpha(128)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(body, style: theme.textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _IngredientRow extends StatelessWidget {
  const _IngredientRow({required this.info, required this.isLast});

  final IngredientInfo info;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(width: 6, color: RiskStyle.color(info.risk)),
          Expanded(
            child: Container(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              decoration: BoxDecoration(
                border: isLast
                    ? null
                    : Border(bottom: BorderSide(color: theme.colorScheme.outlineVariant)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(info.name, style: theme.textTheme.titleMedium),
                  for (final note in info.notes)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        note,
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                      ),
                    ),
                  if (info.allergens.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        'Allergen: ${info.allergens.map((a) => allergenLabels[a] ?? a).join(', ')}',
                        style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
