import 'package:flutter/material.dart';

import '../models/analysis.dart';
import '../models/scan_entry.dart';
import '../services/ingredient_analyzer.dart';
import '../services/storage.dart';
import '../theme.dart';
import 'results_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final HistoryStore _store = HistoryStore();
  List<ScanEntry>? _entries;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await _store.load();
    if (mounted) setState(() => _entries = entries);
  }

  Future<void> _clearAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear all scans?'),
        content: const Text('This removes your scan history from this device.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear all')),
        ],
      ),
    );
    if (confirmed == true) {
      await _store.clear();
      _load();
    }
  }

  String _ago(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes} min ago';
    if (diff.inDays < 1) return '${diff.inHours} h ago';
    if (diff.inDays < 7) return '${diff.inDays} d ago';
    return '${time.year}-${time.month.toString().padLeft(2, '0')}-${time.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final entries = _entries;
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          if (entries != null && entries.isNotEmpty)
            IconButton(
              tooltip: 'Clear all',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: _clearAll,
            ),
        ],
      ),
      body: entries == null
          ? const Center(child: CircularProgressIndicator())
          : entries.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'No scans yet. Scan a label or a dish and it will show up here.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: entries.length,
                  itemBuilder: (context, index) => _tile(entries[index]),
                ),
    );
  }

  Widget _tile(ScanEntry entry) {
    final analysis = IngredientAnalyzer.analyze(entry.ingredients);
    var worst = Risk.safe;
    for (final item in analysis.items) {
      if (item.risk.index > worst.index) worst = item.risk;
    }
    final isLabel = entry.source == ScanSource.label;

    return Dismissible(
      key: ValueKey(entry.id),
      direction: DismissDirection.endToStart,
      background: Container(
        color: Theme.of(context).colorScheme.errorContainer,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete_outline),
      ),
      onDismissed: (_) async {
        await _store.remove(entry.id);
        _load();
      },
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isLabel ? RiskStyle.color(worst).withAlpha(51) : null,
          child: Icon(isLabel ? Icons.receipt_long_outlined : Icons.restaurant_outlined),
        ),
        title: Text(entry.title),
        subtitle: Text('${entry.ingredients.length} ingredients, ${_ago(entry.createdAt)}'),
        trailing: isLabel
            ? Text('${analysis.score}', style: Theme.of(context).textTheme.titleMedium)
            : null,
        onTap: () async {
          await Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => ResultsScreen(entry: entry)),
          );
        },
      ),
    );
  }
}
