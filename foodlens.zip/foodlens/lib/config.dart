/// Build-time settings. Override with --dart-define, for example:
///   flutter run --dart-define=API_BASE_URL=http://192.168.1.20:8000
class AppConfig {
  AppConfig._();

  /// Where the FoodLens backend runs. 10.0.2.2 is the host machine as seen
  /// from the Android emulator. On the iOS simulator use http://localhost:8000.
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );

  /// Optional shared secret. Must match APP_KEY on the backend when it is set.
  static const String appKey = String.fromEnvironment('APP_KEY');

  static const Duration requestTimeout = Duration(seconds: 45);
}
