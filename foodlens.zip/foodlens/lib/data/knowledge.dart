import '../models/analysis.dart';

/// Allergens the app can detect. Keys are stable ids stored in the profile.
const Map<String, String> allergenLabels = {
  'milk': 'Milk',
  'eggs': 'Eggs',
  'peanuts': 'Peanuts',
  'tree_nuts': 'Tree nuts',
  'soy': 'Soy',
  'gluten': 'Gluten',
  'fish': 'Fish',
  'shellfish': 'Shellfish',
  'sesame': 'Sesame',
};

const Map<String, String> dietLabels = {
  'vegan': 'Vegan',
  'vegetarian': 'Vegetarian',
  'halal': 'Halal',
  'gluten_free': 'Gluten-free',
  'dairy_free': 'Dairy-free',
};

/// Headline shown when an ingredient list breaks a diet.
const Map<String, String> dietBreakTitles = {
  'vegan': 'Not vegan',
  'vegetarian': 'Not vegetarian',
  'halal': 'May not be halal',
  'gluten_free': 'Contains gluten',
  'dairy_free': 'Contains dairy',
};

/// Whole-word keywords (plural "s"/"es" is matched automatically).
const Map<String, List<String>> allergenKeywords = {
  'milk': [
    'milk', 'whey', 'casein', 'caseinate', 'lactose', 'lactoglobulin',
    'butter', 'buttermilk', 'cream', 'cheese', 'yogurt', 'yoghurt', 'ghee',
    'curd', 'dairy',
  ],
  'eggs': [
    'egg', 'albumen', 'albumin', 'ovalbumin', 'ovomucoid', 'lysozyme',
    'mayonnaise',
  ],
  'peanuts': ['peanut', 'groundnut', 'arachis'],
  'tree_nuts': [
    'nut', 'almond', 'cashew', 'hazelnut', 'walnut', 'pecan', 'pistachio',
    'macadamia', 'brazil nut', 'chestnut', 'praline', 'marzipan', 'nougat',
    'gianduja',
  ],
  'soy': [
    'soy', 'soya', 'soybean', 'soja', 'edamame', 'tofu', 'tempeh', 'miso',
    'tamari',
  ],
  'gluten': [
    'wheat', 'gluten', 'barley', 'rye', 'malt', 'semolina', 'spelt', 'durum',
    'farina', 'couscous', 'bulgur', 'triticale', 'seitan', 'kamut', 'einkorn',
    'farro',
  ],
  'fish': [
    'fish', 'anchovy', 'anchovies', 'cod', 'salmon', 'tuna', 'sardine',
    'mackerel', 'tilapia', 'haddock', 'pollock', 'trout', 'herring', 'bass',
    'catfish',
  ],
  'shellfish': [
    'shellfish', 'shrimp', 'prawn', 'crab', 'lobster', 'crayfish', 'crawfish',
    'langoustine', 'krill', 'clam', 'mussel', 'oyster', 'scallop', 'squid',
    'octopus', 'abalone', 'crustacean', 'mollusc', 'mollusk',
  ],
  'sesame': ['sesame', 'tahini', 'gingelly'],
};

/// Phrases that look like an allergen but are not, or hide a different one.
/// Applied before keyword matching (whole-phrase, case-insensitive).
const Map<String, String> phraseFixes = {
  'cocoa butter': 'cocoa fat',
  'shea butter': 'shea fat',
  'butter beans': 'lima beans',
  'coconut milk': 'coconut',
  'coconut cream': 'coconut',
  'oat milk': 'oat',
  'rice milk': 'rice',
  'soy milk': 'soy',
  'soya milk': 'soya',
  'almond milk': 'almond',
  'cashew milk': 'cashew',
  'peanut butter': 'peanut',
  'almond butter': 'almond',
  'cashew butter': 'cashew',
  'nut butter': 'nut',
  'sunflower butter': 'sunflower',
  'cream of tartar': 'tartar',
  'water chestnut': 'water tuber',
  'wine vinegar': 'vinegar',
  'gluten-free': 'glutenless',
  'gluten free': 'glutenless',
};

/// Meat, poultry, fish and animal-derived ingredients (breaks vegetarian).
const List<String> meatKeywords = [
  'beef', 'pork', 'bacon', 'ham', 'lamb', 'veal', 'mutton', 'chicken',
  'turkey', 'duck', 'goose', 'venison', 'sausage', 'salami', 'pepperoni',
  'prosciutto', 'chorizo', 'meat', 'poultry', 'lard', 'tallow', 'suet',
  'gelatin', 'gelatine', 'rennet', 'collagen', 'isinglass', 'animal fat',
  'e441',
];

/// Extra animal-derived ingredients that only break vegan (not vegetarian).
const List<String> veganOnlyKeywords = [
  'honey', 'beeswax', 'carmine', 'cochineal', 'shellac', 'royal jelly',
  'propolis', 'lanolin', 'e120', 'e901', 'e904',
];

/// Ingredients that may conflict with halal requirements.
const List<String> halalKeywords = [
  'pork', 'bacon', 'ham', 'lard', 'gelatin', 'gelatine', 'alcohol', 'ethanol',
  'wine', 'beer', 'rum', 'brandy', 'whisky', 'whiskey', 'vodka', 'liqueur',
  'sake', 'mirin', 'e441',
];

class Additive {
  const Additive(
    this.code,
    this.name,
    this.risk,
    this.note, [
    this.aliases = const <String>[],
  ]);

  /// Lowercase E-number such as "e102", or empty for non-coded entries.
  final String code;
  final String name;
  final Risk risk;
  final String note;

  /// Other names it appears under on labels (lowercase).
  final List<String> aliases;
}

const String _azo =
    'Synthetic dye. Some labels warn it may affect attention in children.';

/// A small starter database. Notes are deliberately short and hedged; extend
/// it, or swap in a full additives dataset, as the app grows.
const List<Additive> additives = [
  Additive('e102', 'Tartrazine', Risk.caution, _azo, ['tartrazine']),
  Additive('e104', 'Quinoline yellow', Risk.caution, _azo, ['quinoline yellow']),
  Additive('e110', 'Sunset yellow', Risk.caution, _azo, ['sunset yellow', 'sunset yellow fcf']),
  Additive('e122', 'Carmoisine', Risk.caution, _azo, ['carmoisine', 'azorubine']),
  Additive('e124', 'Ponceau 4R', Risk.caution, _azo, ['ponceau 4r']),
  Additive('e129', 'Allura red', Risk.caution, _azo, ['allura red', 'allura red ac']),
  Additive('e150d', 'Caramel colour IV', Risk.caution,
      'Processing can create 4-MEI, a compound some agencies limit.',
      ['caramel colour iv', 'caramel color iv', 'ammonia sulphite caramel', 'ammonia sulfite caramel']),
  Additive('e171', 'Titanium dioxide', Risk.caution,
      'Banned in EU food since 2022; still allowed in some other countries.',
      ['titanium dioxide']),
  Additive('e211', 'Sodium benzoate', Risk.caution,
      'Preservative. Can form benzene with vitamin C under heat or light.',
      ['sodium benzoate']),
  Additive('e250', 'Sodium nitrite', Risk.caution,
      'Curing agent in processed meat. Frequent high intake is linked to health risks.',
      ['sodium nitrite']),
  Additive('e251', 'Sodium nitrate', Risk.caution,
      'Curing agent in processed meat. Frequent high intake is linked to health risks.',
      ['sodium nitrate']),
  Additive('e320', 'BHA', Risk.caution,
      'Preservative. Some agencies class it as possibly carcinogenic.',
      ['bha', 'butylated hydroxyanisole']),
  Additive('e321', 'BHT', Risk.caution,
      'Preservative. Evidence is mixed, so use is limited.',
      ['bht', 'butylated hydroxytoluene']),
  Additive('e407', 'Carrageenan', Risk.caution,
      'Seaweed thickener. Some people report digestive upset.',
      ['carrageenan']),
  Additive('e433', 'Polysorbate 80', Risk.caution,
      'Emulsifier. Early research suggests possible gut effects.',
      ['polysorbate 80']),
  Additive('e466', 'Carboxymethylcellulose', Risk.caution,
      'Emulsifier. Early research suggests possible gut effects.',
      ['carboxymethylcellulose', 'cellulose gum']),
  Additive('e621', 'Monosodium glutamate', Risk.caution,
      'Flavour enhancer. Safe for most people; some report sensitivity.',
      ['monosodium glutamate', 'msg']),
  Additive('e950', 'Acesulfame K', Risk.caution,
      'Artificial sweetener.', ['acesulfame k', 'acesulfame potassium', 'acesulfame']),
  Additive('e951', 'Aspartame', Risk.caution,
      'Artificial sweetener. Not suitable for people with phenylketonuria.',
      ['aspartame']),
  Additive('e954', 'Saccharin', Risk.caution,
      'Artificial sweetener.', ['saccharin']),
  Additive('e955', 'Sucralose', Risk.caution,
      'Artificial sweetener.', ['sucralose']),
  Additive('e202', 'Potassium sorbate', Risk.safe,
      'Common preservative, low concern.', ['potassium sorbate']),
  Additive('e300', 'Ascorbic acid', Risk.safe, 'Vitamin C.', ['ascorbic acid', 'vitamin c']),
  Additive('e306', 'Tocopherols', Risk.safe, 'Vitamin E antioxidant.', ['tocopherol', 'tocopherols']),
  Additive('e322', 'Lecithin', Risk.safe,
      'Emulsifier, often from soy or sunflower. Check the source if you avoid soy.',
      ['lecithin']),
  Additive('e330', 'Citric acid', Risk.safe, 'Common acidity regulator.', ['citric acid']),
  Additive('e412', 'Guar gum', Risk.safe, 'Plant thickener.', ['guar gum']),
  Additive('e415', 'Xanthan gum', Risk.safe, 'Fermentation-derived thickener.', ['xanthan gum']),
  Additive('e440', 'Pectin', Risk.safe, 'Fruit-derived gelling agent.', ['pectin']),
  Additive('e471', 'Mono- and diglycerides', Risk.safe,
      'Emulsifier. Can come from plants or animals.',
      ['mono and diglycerides', 'mono- and diglycerides']),
  Additive('e960', 'Steviol glycosides', Risk.safe,
      'Stevia-derived sweetener.', ['steviol glycosides', 'stevia']),
  Additive('e120', 'Carmine', Risk.safe, 'Red dye made from insects.', ['carmine', 'cochineal']),
  Additive('e441', 'Gelatine', Risk.safe, 'Animal-derived gelling agent.', ['gelatin', 'gelatine']),
  Additive('e904', 'Shellac', Risk.safe, 'Insect-derived glaze.', ['shellac']),
  Additive('', 'Trans fat', Risk.avoid,
      'Partially hydrogenated oils are the main source of artificial trans fat.',
      ['partially hydrogenated']),
  Additive('', 'High-fructose syrup', Risk.caution,
      'Added sugar. Best kept occasional.',
      ['high fructose corn syrup', 'high-fructose corn syrup', 'glucose-fructose syrup', 'glucose fructose syrup', 'hfcs']),
  Additive('', 'Refined sweetener', Risk.caution,
      'Added sugar with little nutritional value.',
      ['glucose syrup', 'corn syrup', 'invert sugar', 'maltodextrin']),
  Additive('', 'Palm oil', Risk.caution,
      'High in saturated fat; sourcing can be an environmental concern.',
      ['palm oil', 'palm fat']),
];
