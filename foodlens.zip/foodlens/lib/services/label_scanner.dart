import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// On-device OCR for ingredient labels. Works offline.
class LabelScanner {
  Future<String> readText(String imagePath) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(imagePath));
      return result.text;
    } finally {
      await recognizer.close();
    }
  }

  /// Cheap check used by Auto mode to choose between label and food scanning.
  static bool looksLikeIngredientLabel(String text) {
    final t = text.toLowerCase();
    if (t.contains('ingredient')) return true;
    final commas = ','.allMatches(t).length;
    return commas >= 5 && t.length > 80;
  }
}
