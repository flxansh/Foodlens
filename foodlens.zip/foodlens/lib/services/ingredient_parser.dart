import 'ingredient_analyzer.dart';

class ParsedLabel {
  const ParsedLabel({required this.ingredients, this.advisory});

  final List<String> ingredients;

  /// Allergen statements such as "may contain traces of nuts", if any.
  final String? advisory;
}

/// Turns raw OCR text from a food label into a clean ingredient list.
class IngredientParser {
  IngredientParser._();

  static final RegExp _header = RegExp(r'ingredients?\s*[:\-]?', caseSensitive: false);

  // US labels: "Contains 2% or less of: salt, ..." is still the ingredient list.
  static final RegExp _lessThan = RegExp(
    r'contains?\s+\d+(?:[.,]\d+)?\s*%?\s*or\s+less\s+of\s*[:\-]?',
    caseSensitive: false,
  );

  // Where the ingredient list ends and other label sections begin.
  static final RegExp _tail = RegExp(
    r'\b(?:contains|may contain|might contain|allergy advice|allergen information|allergens|'
    r'nutrition facts|nutritional information|nutrition information|storage|store in|'
    r'best before|use by|manufactured|distributed|packed|net wt|net weight|directions)\b',
    caseSensitive: false,
  );

  static final RegExp _statement = RegExp(
    r'\b(?:may contain|might contain|contains|allergy advice|allergen information|allergens)\b[^.\n]{0,160}',
    caseSensitive: false,
  );

  static ParsedLabel parse(String raw) {
    // Join text wrapped after a hyphen ("high-\nfructose"), and normalize
    // "2% or less". The hyphen is kept because it is usually part of the word.
    final withBreaks =
        raw.replaceAll(RegExp(r'-[ \t]*\r?\n\s*'), '-').replaceAll(_lessThan, ', ');

    final advisory = _extractAdvisory(withBreaks);

    var text = withBreaks.replaceAll(RegExp(r'\s+'), ' ').trim();
    final header = _header.firstMatch(text);
    if (header != null) text = text.substring(header.end);
    final tail = _tailStart(text);
    if (tail != null) text = text.substring(0, tail);

    final seen = <String>{};
    final ingredients = <String>[];
    for (final token in _split(text)) {
      final cleaned = _clean(token);
      if (cleaned != null && seen.add(cleaned.toLowerCase())) {
        ingredients.add(cleaned);
      }
    }
    return ParsedLabel(ingredients: ingredients, advisory: advisory);
  }

  static String? _extractAdvisory(String text) {
    final found = <String>[];
    for (final m in _statement.allMatches(text)) {
      if (_depthAt(text, m.start) > 0) continue; // inside an ingredient's brackets
      final statement = m
          .group(0)!
          .replaceAll(RegExp(r'\s+'), ' ')
          .replaceAll(RegExp(r'[\s)\]:;,.\-]+$'), '')
          .trim();
      if (IngredientAnalyzer.allergensIn(statement).isNotEmpty &&
          !found.contains(statement)) {
        found.add(statement);
      }
    }
    return found.isEmpty ? null : found.join('; ');
  }

  static int? _tailStart(String text) {
    for (final m in _tail.allMatches(text)) {
      if (_depthAt(text, m.start) == 0) return m.start;
    }
    return null;
  }

  static int _depthAt(String text, int index) {
    var depth = 0;
    for (var i = 0; i < index; i++) {
      final c = text[i];
      if (c == '(' || c == '[' || c == '{') {
        depth++;
      } else if ((c == ')' || c == ']' || c == '}') && depth > 0) {
        depth--;
      }
    }
    return depth;
  }

  /// Splits on commas, semicolons and bullets that are not inside brackets.
  static List<String> _split(String text) {
    final parts = <String>[];
    final buffer = StringBuffer();
    var depth = 0;
    for (var i = 0; i < text.length; i++) {
      final c = text[i];
      if (c == '(' || c == '[' || c == '{') {
        depth++;
      } else if ((c == ')' || c == ']' || c == '}') && depth > 0) {
        depth--;
      }
      final isDelimiter = c == ',' || c == ';' || c == '\u2022' || c == '\u00B7';
      if (isDelimiter && depth == 0) {
        parts.add(buffer.toString());
        buffer.clear();
      } else {
        buffer.write(c);
      }
    }
    parts.add(buffer.toString());
    return parts;
  }

  static String? _clean(String token) {
    var t = token.trim();
    t = t.replaceAll(RegExp(r'^[\s.\-:*,;]+|[\s.\-:*,;]+$'), '');
    t = t.replaceFirst(RegExp(r'^(?:and|&)\s+', caseSensitive: false), '');
    t = t.replaceAll(RegExp(r'\s+'), ' ');
    if (t.length < 2 || t.length > 120) return null;
    if (!RegExp(r'[A-Za-z]').hasMatch(t)) return null;
    if (t == t.toUpperCase()) t = t.toLowerCase(); // ALL CAPS labels
    t = t.replaceAllMapped(
      RegExp(r'\b[eE](\d{3,4}[a-zA-Z]?)\b'),
      (m) => 'E${m.group(1)!.toLowerCase()}',
    );
    return t[0].toUpperCase() + t.substring(1);
  }
}
