import '../data/knowledge.dart';
import '../models/analysis.dart';

class _Fix {
  const _Fix(this.pattern, this.replacement);
  final RegExp pattern;
  final String replacement;
}

class _AliasRule {
  const _AliasRule(this.additive, this.pattern);
  final Additive additive;
  final RegExp pattern;
}

/// Turns ingredient names into allergen, diet and additive findings.
///
/// Everything here is keyword based, so it is a helpful screen and not a
/// guarantee. The UI says so wherever results are shown.
class IngredientAnalyzer {
  IngredientAnalyzer._();

  static final RegExp _eCode = RegExp(r'\be[\s-]?(\d{3,4}[a-z]?)\b');

  static final List<_Fix> _fixes = [
    for (final e in phraseFixes.entries)
      _Fix(RegExp('\\b${RegExp.escape(e.key)}\\b'), e.value),
  ];

  static final Map<String, RegExp> _allergenRx = {
    for (final e in allergenKeywords.entries) e.key: _anyWord(e.value),
  };

  static final RegExp _vegetarianRx = _anyWord([
    ...meatKeywords,
    ...allergenKeywords['fish']!,
    ...allergenKeywords['shellfish']!,
  ]);

  static final RegExp _veganRx = _anyWord([
    ...meatKeywords,
    ...allergenKeywords['fish']!,
    ...allergenKeywords['shellfish']!,
    ...veganOnlyKeywords,
    ...allergenKeywords['milk']!,
    ...allergenKeywords['eggs']!,
  ]);

  static final RegExp _halalRx = _anyWord(halalKeywords);

  static final Map<String, Additive> _byCode = {
    for (final a in additives)
      if (a.code.isNotEmpty) a.code: a,
  };

  static final List<_AliasRule> _aliasRules = [
    for (final a in additives)
      if (a.aliases.isNotEmpty) _AliasRule(a, _anyWord(a.aliases, plural: false)),
  ];

  static RegExp _anyWord(List<String> words, {bool plural = true}) {
    final body = words.map(RegExp.escape).join('|');
    final suffix = plural ? '(?:s|es)?' : '';
    return RegExp('\\b(?:$body)$suffix\\b');
  }

  static String _normalize(String text) {
    var t = text.toLowerCase();
    for (final fix in _fixes) {
      t = t.replaceAll(fix.pattern, fix.replacement);
    }
    t = t.replaceAllMapped(_eCode, (m) => 'e${m.group(1)}');
    return t.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// Matches against the text as written and with hyphens removed, so a word
  /// broken across lines ("pea-nut") is still recognised.
  static bool _has(RegExp rx, String text) =>
      rx.hasMatch(text) || rx.hasMatch(text.replaceAll('-', ''));

  /// Allergen ids mentioned anywhere in [text].
  static Set<String> allergensIn(String text) {
    final t = _normalize(text);
    return {
      for (final e in _allergenRx.entries)
        if (_has(e.value, t)) e.key,
    };
  }

  static IngredientInfo analyzeIngredient(String name) {
    final text = _normalize(name);

    final allergens = {
      for (final e in _allergenRx.entries)
        if (_has(e.value, text)) e.key,
    };

    final matched = <Additive>[];
    for (final m in _eCode.allMatches(text)) {
      final additive = _byCode['e${m.group(1)}'];
      if (additive != null && !matched.contains(additive)) {
        matched.add(additive);
      }
    }
    for (final rule in _aliasRules) {
      if (!matched.contains(rule.additive) && _has(rule.pattern, text)) {
        matched.add(rule.additive);
      }
    }

    var risk = Risk.safe;
    for (final a in matched) {
      if (a.risk.index > risk.index) risk = a.risk;
    }

    final diets = <String>{};
    if (_has(_veganRx, text)) diets.add('vegan');
    if (_has(_vegetarianRx, text)) diets.add('vegetarian');
    if (_has(_halalRx, text)) diets.add('halal');
    if (allergens.contains('gluten')) diets.add('gluten_free');
    if (allergens.contains('milk')) diets.add('dairy_free');

    return IngredientInfo(
      name: name,
      risk: risk,
      notes: [for (final a in matched) '${a.name}: ${a.note}'],
      allergens: allergens,
      dietFlags: diets,
    );
  }

  static Analysis analyze(List<String> ingredients) {
    final items = ingredients.map(analyzeIngredient).toList();

    final allergens = <String>{};
    final conflicts = <String, Set<String>>{};
    var score = 100;

    for (final item in items) {
      allergens.addAll(item.allergens);
      for (final diet in item.dietFlags) {
        conflicts.putIfAbsent(diet, () => <String>{}).add(_shortName(item.name));
      }
      if (item.risk == Risk.caution) score -= 8;
      if (item.risk == Risk.avoid) score -= 20;
    }

    return Analysis(
      items: items,
      allergens: allergens,
      dietConflicts: conflicts,
      score: score.clamp(0, 100).toInt(),
    );
  }

  /// "Chocolate (sugar, cocoa, milk)" -> "Chocolate".
  static String _shortName(String name) {
    final cut = name.indexOf('(');
    final short = cut > 0 ? name.substring(0, cut).trim() : name.trim();
    return short.isEmpty ? name : short;
  }
}
