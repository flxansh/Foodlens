import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/scan_entry.dart';

class HistoryStore {
  static const String _key = 'history_v1';
  static const int _max = 50;

  Future<List<ScanEntry>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final entries = <ScanEntry>[];
    for (final raw in prefs.getStringList(_key) ?? const <String>[]) {
      try {
        entries.add(ScanEntry.fromJson(jsonDecode(raw) as Map<String, dynamic>));
      } catch (_) {
        // Skip entries saved by an incompatible version.
      }
    }
    return entries;
  }

  Future<void> add(ScanEntry entry) async {
    final entries = await load();
    entries.insert(0, entry);
    await _save(entries.take(_max).toList());
  }

  Future<void> remove(String id) async {
    final entries = await load();
    await _save(entries.where((e) => e.id != id).toList());
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  Future<void> _save(List<ScanEntry> entries) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _key,
      entries.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }
}

/// What the user avoids. Stored on the device only.
class UserProfile {
  const UserProfile({this.allergens = const {}, this.diets = const {}});

  final Set<String> allergens;
  final Set<String> diets;

  bool get isEmpty => allergens.isEmpty && diets.isEmpty;
}

class ProfileStore {
  static const String _allergensKey = 'profile_allergens';
  static const String _dietsKey = 'profile_diets';

  Future<UserProfile> load() async {
    final prefs = await SharedPreferences.getInstance();
    return UserProfile(
      allergens: (prefs.getStringList(_allergensKey) ?? const <String>[]).toSet(),
      diets: (prefs.getStringList(_dietsKey) ?? const <String>[]).toSet(),
    );
  }

  Future<void> save(UserProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_allergensKey, profile.allergens.toList());
    await prefs.setStringList(_dietsKey, profile.diets.toList());
  }
}
