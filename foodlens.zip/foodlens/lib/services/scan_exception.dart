/// An error whose message is safe and useful to show to the user.
class ScanException implements Exception {
  const ScanException(this.message);

  final String message;

  @override
  String toString() => message;
}
