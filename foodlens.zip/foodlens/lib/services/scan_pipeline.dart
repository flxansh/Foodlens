import '../models/scan_entry.dart';
import 'food_vision_service.dart';
import 'ingredient_parser.dart';
import 'label_scanner.dart';
import 'scan_exception.dart';

enum ScanMode { auto, label, food }

/// Photo in, [ScanEntry] out. Picks label OCR or food recognition.
class ScanPipeline {
  ScanPipeline({LabelScanner? labels, FoodVisionService? vision})
      : _labels = labels ?? LabelScanner(),
        _vision = vision ?? FoodVisionService();

  final LabelScanner _labels;
  final FoodVisionService _vision;

  Future<ScanEntry> run(
    String imagePath,
    ScanMode mode, {
    void Function(String status)? onStatus,
  }) async {
    var text = '';
    if (mode != ScanMode.food) {
      onStatus?.call('Reading text…');
      try {
        text = await _labels.readText(imagePath);
      } catch (_) {
        if (mode == ScanMode.label) {
          throw const ScanException(
            "Couldn't read text from this photo. Try again with better light.",
          );
        }
      }
    }

    final isLabel = mode == ScanMode.label ||
        (mode == ScanMode.auto && LabelScanner.looksLikeIngredientLabel(text));

    if (isLabel) {
      final parsed = IngredientParser.parse(text);
      if (parsed.ingredients.isEmpty) {
        throw const ScanException(
          'No ingredient list found. Move closer, add light, or switch to Food mode.',
        );
      }
      return ScanEntry.create(
        source: ScanSource.label,
        title: 'Product label',
        ingredients: parsed.ingredients,
        advisory: parsed.advisory,
      );
    }

    onStatus?.call('Identifying food…');
    final guess = await _vision.analyze(imagePath);
    if (guess.ingredients.isEmpty) {
      throw ScanException(guess.notes ?? 'No food found in this photo.');
    }
    return ScanEntry.create(
      source: ScanSource.food,
      title: guess.title,
      ingredients: guess.ingredients,
      note: guess.notes,
    );
  }
}
