import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../config.dart';
import 'scan_exception.dart';

class FoodGuess {
  const FoodGuess({
    required this.title,
    required this.ingredients,
    required this.confidence,
    this.notes,
  });

  final String title;
  final List<String> ingredients;
  final String confidence;
  final String? notes;
}

/// Sends a photo of a dish to the FoodLens backend, which asks a vision model
/// to name the food and list its likely ingredients.
class FoodVisionService {
  Future<FoodGuess> analyze(String imagePath) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/analyze-food');
    final request = http.MultipartRequest('POST', uri);
    if (AppConfig.appKey.isNotEmpty) {
      request.headers['X-App-Key'] = AppConfig.appKey;
    }
    request.files.add(await http.MultipartFile.fromPath('image', imagePath));

    try {
      final streamed = await request.send().timeout(AppConfig.requestTimeout);
      final body = await streamed.stream.bytesToString();
      if (streamed.statusCode != 200) {
        throw ScanException(
          'The food analysis service returned an error (${streamed.statusCode}). Try again in a moment.',
        );
      }
      final json = jsonDecode(body) as Map<String, dynamic>;
      final ingredients = (json['ingredients'] as List? ?? const [])
          .map((e) => e.toString().trim())
          .where((e) => e.isNotEmpty)
          .toList();
      return FoodGuess(
        title: (json['title'] as String?)?.trim().isNotEmpty == true
            ? (json['title'] as String).trim()
            : 'Food photo',
        ingredients: ingredients,
        confidence: (json['confidence'] as String?) ?? 'medium',
        notes: json['notes'] as String?,
      );
    } on SocketException {
      throw const ScanException(
        "Can't reach the food analysis service. Check your connection and the server address.",
      );
    } on TimeoutException {
      throw const ScanException('The food analysis took too long. Please try again.');
    } on FormatException {
      throw const ScanException("The food analysis service sent a reply the app couldn't read.");
    } on TypeError {
      throw const ScanException("The food analysis service sent a reply the app couldn't read.");
    }
  }
}
