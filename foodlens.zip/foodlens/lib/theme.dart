import 'package:flutter/material.dart';

import 'models/analysis.dart';

const Color _seed = Color(0xFF24564C);

ThemeData buildTheme(Brightness brightness) {
  final scheme = ColorScheme.fromSeed(seedColor: _seed, brightness: brightness);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    appBarTheme: const AppBarTheme(centerTitle: false),
  );
}

/// The traffic-light colors used everywhere an ingredient is judged.
class RiskStyle {
  RiskStyle._();

  static Color color(Risk risk) {
    switch (risk) {
      case Risk.safe:
        return const Color(0xFF1E8A5A);
      case Risk.caution:
        return const Color(0xFFD99A00);
      case Risk.avoid:
        return const Color(0xFFCF3F3F);
    }
  }

  static String label(Risk risk) {
    switch (risk) {
      case Risk.safe:
        return 'Fine';
      case Risk.caution:
        return 'Watch';
      case Risk.avoid:
        return 'Avoid';
    }
  }
}
